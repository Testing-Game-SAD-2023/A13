package com.g2.tests;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.List;
import java.util.stream.Collectors;

public class LeaderboardWinsOrderTest extends BaseTest {

    @Test
    public void testScoresAreOrderedCorrectly() {
        // Assicurarsi di essere nella pagina di leaderboard
        driver.get("http://localhost/leaderboard");

        // Selezionare l'ordine per 'totalScore' se non già selezionato
        WebElement sortOrderSelect = new WebDriverWait(driver, Duration.ofSeconds(10))
            .until(ExpectedConditions.elementToBeClickable(By.id("sortOrder")));
        sortOrderSelect.click();
        WebElement totalScoreOption = sortOrderSelect.findElement(By.xpath("//option[@value='wins']"));
        if (!totalScoreOption.isSelected()) {
            totalScoreOption.click();
        }

        // Ricarica la pagina con l'ordinamento corretto
        driver.navigate().refresh();

        List<WebElement> voidlisttest = driver.findElements(By.xpath("//tbody/tr/td[5]")); // Assumendo che totalScore sia la quinta colonna
        if (voidlisttest.isEmpty()) {
            System.out.println("Nessun giocatore presente nella leaderboard.");
            return; // Esce dal test se non ci sono giocatori
        }

        // Raccogliere i punteggi dal sito e trasformarli in una lista di Integer
        List<Integer> scores = driver.findElements(By.xpath("//tbody/tr/td[4]")) // Assumendo che totalScore sia la quinta colonna
            .stream()
            .map(WebElement::getText)
            .map(Integer::parseInt)
            .collect(Collectors.toList());

        // Verificare che i punteggi siano ordinati in modo decrescente
        for (int i = 0; i < scores.size() - 1; i++) {
            Assertions.assertTrue(scores.get(i) >= scores.get(i + 1), "I punteggi non sono ordinati correttamente.");
        }
    }
}
