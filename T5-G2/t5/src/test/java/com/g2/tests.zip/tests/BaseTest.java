package com.g2.tests;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.chrome.ChromeOptions;

public abstract class BaseTest {

    protected WebDriver driver;
    
    @BeforeEach
    public void setup() {
        WebDriverManager.chromedriver().setup();
        // Configura le opzioni di Chrome
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--no-sandbox"); // Disabilita la sandbox per evitare errori se eseguito come root (non raccomandato in produzione)
        options.addArguments("--disable-dev-shm-usage"); // Risolve problemi di memoria in ambienti come Docker
        options.addArguments("--headless"); // Esegue test senza aprire una finestra del browser (utile per ambienti di CI/CD)

        // Crea un'istanza di ChromeDriver con le opzioni configurate
        driver = new ChromeDriver(options);

        driver.get("http://localhost/login");

        // Login automatico
        performLogin("izio.5555@gmail.com", "Napoli99@");
    }

    private void performLogin(String email, String password) {
        driver.findElement(By.id("email")).sendKeys(email);
        driver.findElement(By.id("password")).sendKeys(password);
        driver.findElement(By.cssSelector("input[type='submit']")).click();

        // Aggiungi un breve ritardo per attendere il completamento del reindirizzamento
        try {
            Thread.sleep(3000); // Aspetta 3 secondi (3000 millisecondi)
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        // Verifica che la pagina corrente sia quella corretta
        Assertions.assertEquals("http://localhost/main", driver.getCurrentUrl(), "L'URL non corrisponde a /main dopo il login.");
    }

    @AfterEach
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
