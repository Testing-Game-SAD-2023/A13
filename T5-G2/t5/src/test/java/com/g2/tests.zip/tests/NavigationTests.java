package com.g2.tests;  // Assicurati che il package corrisponda alla struttura della tua directory

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class NavigationTests extends BaseTest {

    @Test
    void testLeaderboardNavigation() {
        // Assicurati che il login sia stato completato correttamente
        Assertions.assertEquals("http://localhost/main", driver.getCurrentUrl(), "Il reindirizzamento dopo il login non è corretto.");

        // Clicca sul link della classifica nella navbar
        WebElement leaderboardLink = driver.findElement(By.linkText("Classifica"));
        leaderboardLink.click();

        // Aspetta che la navigazione sia completa e verifica l'URL
        new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.urlToBe("http://localhost/leaderboard"));

        // Verifica che l'URL sia corretto
        Assertions.assertEquals("http://localhost/leaderboard", driver.getCurrentUrl(), "La navigazione alla pagina della classifica non è avvenuta correttamente.");
    }
}
