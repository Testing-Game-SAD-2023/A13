package mypackage;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
RegressionTest0_it6_livello5.class, 
RegressionTest1_it6_livello5.class, 
RegressionTest2_it6_livello5.class, 
RegressionTest3_it6_livello5.class, 
RegressionTest4_it6_livello5.class
})
public class RegressionTest_it6_livello5{ }
