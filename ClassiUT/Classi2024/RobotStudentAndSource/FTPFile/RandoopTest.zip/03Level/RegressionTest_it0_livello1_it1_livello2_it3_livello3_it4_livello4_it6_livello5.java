package mypackage;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
RegressionTest0_it0_livello1_it1_livello2_it3_livello3_it4_livello4_it6_livello5.class
})
public class RegressionTest_it0_livello1_it1_livello2_it3_livello3_it4_livello4_it6_livello5{ }
