package mypackage;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
RegressionTest0_it4_livello4_it6_livello5.class, 
RegressionTest1_it4_livello4_it6_livello5.class, 
RegressionTest2_it4_livello4_it6_livello5.class
})
public class RegressionTest_it4_livello4_it6_livello5{ }
