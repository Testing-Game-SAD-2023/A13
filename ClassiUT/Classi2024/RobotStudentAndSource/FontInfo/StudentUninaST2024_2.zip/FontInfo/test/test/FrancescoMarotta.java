package test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import java.awt.Font;
import ClassUnderTest.FontInfo;

public class FrancescoMarotta {

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testFontInfoDefaultConstructor() {
        FontInfo fontInfo = new FontInfo();
        // Verifica dei valori predefiniti del costruttore di FontInfo
        assertEquals("Monospaced", fontInfo.getFamily());
        assertEquals(12, fontInfo.getSize());
        assertFalse(fontInfo.isBold());
        assertFalse(fontInfo.isItalic());
    }

    @Test
    public void testFontInfoWithFont() {
        // Creazione di un oggetto Font personalizzato
        Font font = new Font("Serif", Font.BOLD, 14);
        FontInfo fontInfo = new FontInfo(font);
        // Verifica dei valori impostati tramite il costruttore
        assertEquals("Serif", fontInfo.getFamily());
        assertEquals(14, fontInfo.getSize());
        assertTrue(fontInfo.isBold());
        assertFalse(fontInfo.isItalic());
    }

    @Test
    public void testFontInfoWithNullFont() {
        // Verifica che venga lanciata un'eccezione per un font nullo
        assertThrows(IllegalArgumentException.class, () -> new FontInfo(null));
    }

    @Test
    public void testSetFontWithNull() {
        Font font = null;
        FontInfo fontInfo = new FontInfo();
        // Verifica che venga lanciata un'eccezione per un font nullo
        assertThrows(IllegalArgumentException.class, () -> fontInfo.setFont(font));
    }

    @Test
    public void testClone() {
        FontInfo original = new FontInfo();
        FontInfo cloned = (FontInfo) original.clone();
        // Verifica che il clone non sia nullo e che sia uguale all'originale
        assertNotNull(cloned);
        assertEquals(original, cloned);
    }

    @Test
    public void testGetFamily() {
        FontInfo fontInfo = new FontInfo();
        fontInfo.setFamily("Serif");
        // Verifica che la famiglia venga impostata correttamente
        assertEquals("Serif", fontInfo.getFamily());
        fontInfo.setFamily(null);
        // Verifica che, se impostata a null, venga utilizzata la famiglia predefinita
        assertEquals("Monospaced", fontInfo.getFamily());
    }

    @Test
    public void testIsBold() {
        FontInfo fontInfo = new FontInfo();
        // Verifica che lo stato di bold sia inizialmente false
        assertFalse(fontInfo.isBold());
        fontInfo.setIsBold(true);
        // Verifica che lo stato di bold venga impostato correttamente
        assertTrue(fontInfo.isBold());
    }

    @Test
    public void testSetIsBold() {
        FontInfo fontInfo = new FontInfo();
        fontInfo.setIsBold(true);
        // Verifica che lo stato di bold venga aggiornato correttamente
        assertTrue(fontInfo.isBold());
    }

    @Test
    public void testIsItalic() {
        FontInfo fontInfo = new FontInfo();
        // Verifica che lo stato di italic sia inizialmente false
        assertFalse(fontInfo.isItalic());
        fontInfo.setIsItalic(true);
        // Verifica che lo stato di italic venga impostato correttamente
        assertTrue(fontInfo.isItalic());
    }

    @Test
    public void testSetIsItalic() {
        FontInfo fontInfo = new FontInfo();
        fontInfo.setIsItalic(true);
        // Verifica che lo stato di italic venga aggiornato correttamente
        assertTrue(fontInfo.isItalic());
    }

    @Test
    public void testGetSize() {
        FontInfo fontInfo = new FontInfo();
        fontInfo.setSize(16);
        // Verifica che la dimensione venga impostata correttamente
        assertEquals(16, fontInfo.getSize());
    }

    @Test
    public void testSetSize() {
        FontInfo fontInfo = new FontInfo();
        fontInfo.setSize(18);
        // Verifica che la dimensione venga aggiornata correttamente
        assertEquals(18, fontInfo.getSize());
    }

    @Test
    public void testDoesFontMatch() {
        FontInfo fontInfo = new FontInfo();
        fontInfo.setFamily("Serif");
        fontInfo.setSize(12);
        fontInfo.setIsBold(true);
        
        Font fontMatch = new Font("Serif", Font.BOLD, 12);
        // Verifica che la corrispondenza tra fontInfo e fontMatch sia corretta
        assertTrue(fontInfo.doesFontMatch(fontMatch));

        Font fontMismatch = new Font("Monospaced", Font.PLAIN, 12);
        // Verifica che non ci sia corrispondenza tra fontInfo e fontMismatch
        assertFalse(fontInfo.doesFontMatch(fontMismatch));
        
        Font fontNull = null;
        // Verifica che il confronto con un font nullo restituisca false
        assertFalse(fontInfo.doesFontMatch(fontNull));
    }

    @Test
    public void testGenerateStyle() {
        FontInfo fontInfo = new FontInfo();
        fontInfo.setIsBold(true);
        fontInfo.setIsItalic(true);
        // Verifica che il metodo generi correttamente il valore di stile
        assertEquals(Font.BOLD | Font.ITALIC, fontInfo.generateStyle());

        fontInfo.setIsBold(false);
        fontInfo.setIsItalic(false);
        assertEquals(Font.PLAIN, fontInfo.generateStyle());
    }

    @Test
    public void testCreateFont() {
        FontInfo fontInfo = new FontInfo();
        fontInfo.setFamily("Serif");
        fontInfo.setIsBold(true);
        fontInfo.setSize(14);
        
        Font createdFont = fontInfo.createFont();
        // Verifica che il font creato abbia le proprietà corrette
        assertEquals("Serif", createdFont.getFamily());
        assertEquals(14, createdFont.getSize());
        assertTrue(createdFont.isBold());
    }

    @Test
    public void testToString() {
        FontInfo fontInfo = new FontInfo();
        fontInfo.setFamily("Arial");
        fontInfo.setSize(12);
        fontInfo.setIsBold(true);
        fontInfo.setIsItalic(false);
        
        String expectedString = "Arial, 12, bold";
        // Verifica che il metodo toString restituisca la rappresentazione corretta
        assertEquals(expectedString, fontInfo.toString());
        
        FontInfo fontInfo2 = new FontInfo();
        fontInfo2.setFamily("Arial");
        fontInfo2.setSize(12);
        fontInfo2.setIsBold(false);
        fontInfo2.setIsItalic(true);
        
        String expectedString2 = "Arial, 12, italic";
        assertEquals(expectedString2, fontInfo2.toString());
    }

    @Test
    public void testEqualsObject() {
        FontInfo fontInfo1 = new FontInfo();
        FontInfo fontInfo2 = new FontInfo();
        
        // Verifica che due oggetti identici siano considerati uguali
        assertEquals(fontInfo1, fontInfo1);
        assertEquals(fontInfo1, fontInfo2);
        
        fontInfo1.setFamily("Arial");
        // Verifica che cambiare un attributo renda gli oggetti non uguali
        assertNotEquals(fontInfo1, fontInfo2);
        
        fontInfo2.setFamily("Arial");
        assertEquals(fontInfo1, fontInfo2);
        
        fontInfo1.setIsBold(true);
        assertNotEquals(fontInfo1, fontInfo2);
        
        fontInfo2.setIsBold(true);
        assertEquals(fontInfo1, fontInfo2);
        
        fontInfo1.setSize(14);
        assertNotEquals(fontInfo1, fontInfo2);
        
        fontInfo2.setSize(14);
        assertEquals(fontInfo1, fontInfo2);
        
        fontInfo2.setIsItalic(true);
        assertNotEquals(fontInfo1, fontInfo2);
        
        fontInfo2 = null;
        assertNotEquals(fontInfo1, fontInfo2);
        
        String testString = new String("test");
        assertNotEquals(fontInfo1, testString);
        
        fontInfo1.setFamily(null);
        assertNotEquals(fontInfo1, fontInfo2);
    }

    @Test
    public void testHashCode() {
        FontInfo fontInfo1 = new FontInfo();
        FontInfo fontInfo2 = new FontInfo();
        // Verifica che oggetti uguali abbiano lo stesso hash code
        assertEquals(fontInfo1.hashCode(), fontInfo2.hashCode());

        fontInfo1.setFamily("Arial");
        // Verifica che cambiamenti in uno degli oggetti influiscano sull'hash code
        assertNotEquals(fontInfo1.hashCode(), fontInfo2.hashCode());
        fontInfo1.setIsBold(false);
        assertNotEquals(fontInfo1.hashCode(), fontInfo2.hashCode());
    }
}
