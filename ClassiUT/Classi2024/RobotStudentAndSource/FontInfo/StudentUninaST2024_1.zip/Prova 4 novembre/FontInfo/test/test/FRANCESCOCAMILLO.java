package test;

import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

import java.awt.Font;
import ClassUnderTest.FontInfo;

public class StudentTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testHashCode() { 
		
		FontInfo fhc = new FontInfo();
		assertNotNull(fhc.hashCode());
		
	}
	
	@Test
	public void testHashCode2() { 
		
		//Questo metodo di test ha l'obiettivo di verificare che i due hashcode siano uguali
		
		Font fonthc2 = new Font("FontItalic", Font.ITALIC, 18);
		FontInfo fhc1= new FontInfo(fonthc2);
		FontInfo fhc2= new FontInfo(fonthc2);
		assertEquals(fhc1.hashCode(), fhc2.hashCode());
		
	}
	
	@Test
	public void testHashCode3() { 
		
		//Questo metodo di test ha l'obiettivo di verificare che i due hashcode siano uguali 
		//ma con un font diverso rispetto al metodo precedente
		
		Font fonthc3 = new Font("FontItalic", Font.BOLD, 18);
		FontInfo fhcone= new FontInfo(fonthc3);
		FontInfo fhctwo= new FontInfo(fonthc3);
		assertEquals(fhcone.hashCode(),fhctwo.hashCode());
	
	}
	
	
	@Test
	public void testFontInfo() {
	
		FontInfo finfo = new FontInfo();
		assertNotNull(finfo);
		
	}
			
	@Test
	public void testFontInfoFont() {

		Font fontinf = new Font("SansSerif", Font.PLAIN, 14);
		FontInfo FINF= new FontInfo(fontinf);
		assertNotNull(FINF);
		
	}

	@Test
	public void testClone() {
		
		Font fonttc = new Font("NewFont", Font.BOLD, 19);
		FontInfo FTC= new FontInfo(fonttc);
		Object objectClone=FTC.clone();
		FontInfo fiinfclone=(FontInfo)objectClone;
	
		
	}

	@Test
	public void testGetFamily() {
		
		//questo metodo serve per verificare che sia restituito family
		
		Font font = new Font("SansSerif", Font.PLAIN, 14);
		FontInfo fi2= new FontInfo(font);
		String s1= fi2.getFamily();
		assertEquals("SansSerif", s1);
		
	}
	

	@Test
	public void testIsBold() {
		
		//test per vedere se il font è bold o meno
		
		Font font = new Font("FontNotBold", Font.PLAIN, 14);
		FontInfo fib= new FontInfo(font);
		boolean b1= fib.isBold();
		assertEquals(false,b1);
	}
	
	@Test
	public void testIsBold2() {
		
		//Istanzio un oggetto con Font Bold per testare che isBold restituisca true
		
		Font font2= new Font("FontBold", Font.BOLD, 13);
		FontInfo fib3=new FontInfo(font2);
		boolean b2= fib3.isBold();
		assertEquals(true, b2);
		
	}

	@Test
	public void testSetIsBold() {

		//invoco il metodo setIsBold per settare come true un valore di _isBold
		//che e' false verificandolo con assertEquals
		
		Font font = new Font("SansSerif", Font.PLAIN, 14);
		FontInfo fib2= new FontInfo(font);
		assertEquals(false,fib2.isBold());
		boolean b=true;
		fib2.setIsBold(b);
		assertEquals(true,b);
	
	}

	@Test
	public void testIsItalic() {
	
		Font fontItal = new Font("FontItalic", Font.ITALIC, 18);
		FontInfo fibI= new FontInfo(fontItal);	
		boolean I1= fibI.isItalic();
		assertEquals(true, I1);
	}

	@Test
	public void testSetIsItalic() {
		
		//Invoco il metodo setIsItalic su un oggetto che non è stato istanziato 
		//come italic in modo da modificarne il valore
		
		Font fontNotItal = new Font("FontNotItalic", Font.BOLD, 18);
		FontInfo fibNI= new FontInfo(fontNotItal);
		assertFalse(fibNI.isItalic());
		boolean I2=true;
		fibNI.setIsItalic(I2);
		assertTrue(fibNI.isItalic());
		
	}

	@Test
	public void testGetSize() {
		
		//Testo il metodo GetSize con un oggetto che inizializza size a 22
		
		Font fontGS = new Font("FontItalic", Font.ITALIC, 22);
		FontInfo fibGS= new FontInfo(fontGS);
		int gs= fibGS.getSize();
		assertEquals(22,gs);
		
	}

	@Test
	public void testSetSize() {
		
		//Istanzio un oggetto e poi invoco il metodo setSize per modificare il 
		//valore di size
		
		Font fontSS = new Font("FontItalic", Font.ITALIC, 19);
		FontInfo fibSS= new FontInfo(fontSS);	
		fibSS.setSize(25);
		assertEquals(25,fibSS.getSize());
	
	}
	
	@Test
	public void testSetFont() {
		
		//Test per l'eccezione di setFont
		
		Font fontSF = new Font("FontItalic", Font.ITALIC, 19);
		FontInfo fibSF= new FontInfo(fontSF);
		assertThrows(IllegalArgumentException.class, ()->fibSF.setFont(null));
		
		
	}
	
	@Test
	public void testSetFamily() {
		
		//invoco il metodo setFamily passando come parametro null in modo
		//da poter coprire in verde la riga 53 ovvero il metodo setFamily
		//il quale implementa ? : 
		
		Font fontf = new Font("newFont", Font.ITALIC, 15);
		FontInfo fif= new FontInfo(fontf);
		fif.setFamily(null);	
		assertEquals("Monospaced", fif.getFamily());
		
	}

	@Test
	public void testDoesFontMatch() {
	
		//Caso in cui corrispondono 
		
		Font fontdfm = new Font("newFontdfm", Font.ITALIC, 15);
		FontInfo fidfm= new FontInfo(fontdfm);
		
		Font fontone= new Font("newFontdfm", Font.ITALIC, 15);
		
		assertTrue(fidfm.doesFontMatch(fontone));
		
	}

	
	@Test
	public void testDoesFontMatch2() {
	
		//Caso in cui non corrispondono a causa di size
		
		Font fontdfm2 = new Font("newFontdfm", Font.ITALIC, 15);
		FontInfo fidfm2= new FontInfo(fontdfm2);
		
		Font font2= new Font("newFontdfm", Font.ITALIC, 18);	
		
		assertFalse(fidfm2.doesFontMatch(font2));
		
	
	}




	@Test
	public void testDoesFontMatch3() {
	
		//Caso in cui non corrispondono a causa di Font
		
		Font fontdfm3 = new Font("newFontdfm", Font.BOLD, 15);
		FontInfo fidfm3= new FontInfo(fontdfm3);
		
		Font font3= new Font("newFontdfm", Font.ITALIC, 15);
		
		assertFalse(fidfm3.doesFontMatch(font3));
			
	}

	@Test
	public void testDoesFontMatch4() {
	
		//Caso in cui corrispondono a causa di family
		
		Font fontdfm4 = new Font("newFontdfm", Font.BOLD, 15);
		FontInfo fidfm4= new FontInfo(fontdfm4);
		
		Font font4= new Font("fontdiverso", Font.ITALIC, 15);
		
		assertFalse(fidfm4.doesFontMatch(font4));
			
	}
	

	@Test
	public void testDoesFontMatch5() {
			
		Font fontdfm5 = new Font("newFontdfm", Font.BOLD, 15);
		FontInfo fidfm5= new FontInfo(fontdfm5);
		
		assertFalse(fidfm5.doesFontMatch(null));
		
	}

	
	@Test
	public void testGenerateStyle() {
	
			Font fgstyle = new Font("newFontItalic", Font.ITALIC, 15);
			FontInfo FGstyle= new FontInfo(fgstyle);
			
			int f=FGstyle.generateStyle();
			assertEquals(Font.ITALIC, f);
		}
	
	@Test
	public void testGenerateStyle2() {
	
		Font fgstyle2 = new Font("newFontBold", Font.BOLD, 15);
		FontInfo FGstyle2= new FontInfo(fgstyle2);
		
		int f2=FGstyle2.generateStyle();
		assertEquals(Font.BOLD, f2);
			
	}
	
	@Test
	public void testGenerateStyle3() {
	
		Font fgstyle3 = new Font("newFontPlain", Font.PLAIN, 15);
		FontInfo FGstyle3= new FontInfo(fgstyle3);
		
		int f3=FGstyle3.generateStyle();
		assertEquals(Font.PLAIN, f3);
			
	}
	
	@Test
	public void test_CreateFont()
	{
		 Font fcf = new Font("SansSerif", Font.PLAIN, 14);
		
		 FontInfo finfocf = new FontInfo(fcf);
		
		 Font nuovofont = finfocf.createFont();
		
		 assertEquals(fcf,nuovofont);
		 
	}

	@Test
	public void testToString1(){
		
		//Metodo per verificare che l'output coincida con la stringa 
		
		Font fontts = new Font("SansSerif", Font.ITALIC, 14);
		 FontInfo FONTTS = new FontInfo(fontts);
		
		 String stringts = "SansSerif, 14, italic";
		 
		 assertEquals(stringts, FONTTS.toString());
		 
	}
	
	@Test
	public void testToString2() {
		
		
		Font fontts2 = new Font("SansSerif", Font.ITALIC, 14);
		 FontInfo FONTTS2 = new FontInfo(fontts2);
		
		 String stringts2="SansSerif, 14, italic";
		 
		 assertEquals(stringts2, FONTTS2.toString());
		 }

		@Test
	    public void testEqualsMatchingObjects() {
		
			//Test per verificare che i due oggetti siano uguali
			
			Font fieq = new Font("SansSerif", Font.ITALIC, 14);
	        FontInfo FIEQ = new FontInfo(fieq);
	        
	        FontInfo FIEQ2 = new FontInfo(fieq);
	        
	        assertEquals(true, FIEQ.equals(FIEQ2));     
	    }

}
