package mypackage;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
RegressionTest0_it1_livello2_it2_livello3.class, 
RegressionTest1_it1_livello2_it2_livello3.class
})
public class RegressionTest_it1_livello2_it2_livello3{ }
