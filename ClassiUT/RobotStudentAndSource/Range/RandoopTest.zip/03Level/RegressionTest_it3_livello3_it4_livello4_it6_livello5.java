package mypackage;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
RegressionTest0_it3_livello3_it4_livello4_it6_livello5.class
})
public class RegressionTest_it3_livello3_it4_livello4_it6_livello5{ }
