package mypackage;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
ErrorTest0_it1_livello2.class
})
public class ErrorTest_it1_livello2{ }
