package mypackage;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
RegressionTest0_it3_livello3.class, 
RegressionTest1_it3_livello3.class, 
RegressionTest2_it3_livello3.class, 
RegressionTest3_it3_livello3.class
})
public class RegressionTest_it3_livello3{ }
