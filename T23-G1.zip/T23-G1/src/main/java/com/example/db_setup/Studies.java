package com.example.db_setup;

public enum Studies {
    BSc,
    MSc,
    ALTRO
}
