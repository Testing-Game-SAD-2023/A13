/*package com.example.db_setup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbSetupApplicationTests {

    @Test
    void contextLoads() {
    }

}
*/